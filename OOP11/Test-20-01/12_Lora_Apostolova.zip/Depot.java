public class Depot extends Node{
    public Depot(String name){super name}
}