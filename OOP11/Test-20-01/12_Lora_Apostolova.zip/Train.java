public class Train extends Vehicle{
    public Train(Node start, Node destination){super start, destination}
}