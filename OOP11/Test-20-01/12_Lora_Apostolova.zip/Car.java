public class Car extends Vehicle{
    public Car(Node start, Node destination){super start, destination}
}