public class EmergencyCar extends Vehicle{
    public EmergencyCar(Node start, Node destination){super start, destination}
}