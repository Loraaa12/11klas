package Bank;

public class Transaction {
    public enum type {
        Transfer, Deposit, Withdraw;
     }
    private double amount;

}