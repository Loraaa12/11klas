interface IRequirement {
    boolean test(Player player);
    void take(Player player);
}