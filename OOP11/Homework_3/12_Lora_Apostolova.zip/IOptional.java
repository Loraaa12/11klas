interface IOptional {
    boolean test(Player player);
}